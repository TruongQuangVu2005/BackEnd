﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        List<HoiVien> danhSachHoiVien = new List<HoiVien>();

        Console.Write("Nhap so luong hoi vien: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhap thong tin hoi vien {i + 1}:");
            HoiVien hoiVien = NhapHoiVien();
            danhSachHoiVien.Add(hoiVien);
        }

        // Tìm kiếm hội viên có ngày cưới là: 11.11.2011  
        Console.WriteLine("\nDanh sach hoi vien co ngay cuoi la 11.11.2011:");
        foreach (var hv in danhSachHoiVien)
        {
            if (hv is DaCoGiaDinh && ((DaCoGiaDinh)hv).NgayCuoi.ToString("dd.MM.yyyy") == "11.11.2011")
            {
                hv.InThongTin();
            }
        }

        // Hiển thị thông tin cho những người đã có người yêu nhưng chưa lập gia đình  
        Console.WriteLine("\nDanh sach hoi vien da co nguoi yeu nhung chua lap gia dinh:");
        foreach (var hv in danhSachHoiVien)
        {
            if (hv is ChuaCoGiaDinh)
            {
                ((ChuaCoGiaDinh)hv).InThongTin();
            }
        }
    }

    static HoiVien NhapHoiVien()
    {
        Console.Write("Nhap ho ten: ");
        string hoTen = Console.ReadLine();

        Console.Write("Nhap dia chi: ");
        string diaChi = Console.ReadLine();

        Console.Write("1. Da co gia dinh\n2. Chua co gia dinh\nChon loai hoi vien (1/2): ");
        int loai = int.Parse(Console.ReadLine());

        if (loai == 1)
        {
            return NhapDaCoGiaDinh(hoTen, diaChi);
        }
        else
        {
            return NhapChuaCoGiaDinh(hoTen, diaChi);
        }
    }

    static DaCoGiaDinh NhapDaCoGiaDinh(string hoTen, string diaChi)
    {
        Console.Write("Nhap ho ten vo: ");
        string hoTenVo = Console.ReadLine();

        Console.Write("Nhap ngay cuoi (dd/MM/yyyy): ");
        DateTime ngayCuoi = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);

        return new DaCoGiaDinh(hoTen, diaChi, hoTenVo, ngayCuoi);
    }

    static ChuaCoGiaDinh NhapChuaCoGiaDinh(string hoTen, string diaChi)
    {
        Console.Write("Nhap ho ten nguoi yeu: ");
        string hoTenNguoiYeu = Console.ReadLine();

        Console.Write("Nhap so dien thoai nguoi yeu: ");
        string soDienThoaiNguoiYeu = Console.ReadLine();

        return new ChuaCoGiaDinh(hoTen, diaChi, hoTenNguoiYeu, soDienThoaiNguoiYeu);
    }
}

// Lớp HoiVien (hội viên)  
class HoiVien
{
    public string HoTen { get; set; }
    public string DiaChi { get; set; }

    public HoiVien(string hoTen, string diaChi)
    {
        HoTen = hoTen;
        DiaChi = diaChi;
    }

    public HoiVien() { }

    public virtual void InThongTin()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Dia chi: {DiaChi}");
    }
}

// Lớp DaCoGiaDinh (Đã có gia đình)  
class DaCoGiaDinh : HoiVien
{
    public string HoTenVo { get; set; }
    public DateTime NgayCuoi { get; set; }

    public DaCoGiaDinh(string hoTen, string diaChi, string hoTenVo, DateTime ngayCuoi)
        : base(hoTen, diaChi)
    {
        HoTenVo = hoTenVo;
       