﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Nhap ma tran A:");
        MaTran A = new MaTran();
        A.Nhap();

        Console.WriteLine("Nhap ma tran B:");
        MaTran B = new MaTran();
        B.Nhap();

        int luaChon;
        do
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Tong hai ma tran");
            Console.WriteLine("2. Hieu hai ma tran");
            Console.WriteLine("3. Tich hai ma tran");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    try
                    {
                        MaTran tong = A.Cong(B);
                        Console.WriteLine("Tong hai ma tran A + B:");
                        tong.HienThi();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;

                case 2:
                    try
                    {
                        MaTran hieu = A.Hieu(B);
                        Console.WriteLine("Hieu hai ma tran A - B:");
                        hieu.HienThi();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;

                case 3:
                    try
                    {
                        MaTran tich = A.Nhan(B);
                        Console.WriteLine("Tich hai ma tran A * B:");
                        tich.HienThi();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;

                case 4:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 4);
    }
}

// Lớp MaTran  
class MaTran
{
    private int soDong; // Số dòng  
    private int soCot;  // Số cột  
    private double[,] mang; // Mảng hai chiều để lưu trữ các phần tử của ma trận  

    // Hàm tạo mặc định  
    public MaTran() : this(0, 0) { }

    // Hàm tạo với số dòng và số cột  
    public MaTran(int n, int m)
    {
        soDong = n;
        soCot = m;
        mang = new double[soDong, soCot];
    }

    // Phương thức nhập ma trận  
    public void Nhap()
    {
        Console.Write("Nhap so dong: ");
        soDong = int.Parse(Console.ReadLine());
        Console.Write("Nhap so cot: ");
        soCot = int.Parse(Console.ReadLine());
        mang = new double[soDong, soCot];

        Console.WriteLine("Nhap cac phan tu:");
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                Console.Write($"a[{i + 1},{j + 1}] = ");
                mang[i, j] = double.Parse(Console.ReadLine());
            }
        }
    }

    // Phương thức hiển thị ma trận  
    public void HienThi()
    {
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                Console.Write($"{mang[i, j]:F2}  "); // Hiển thị với 2 chữ số thập phân  
            }
            Console.WriteLine();
        }
    }

    // Phương thức cộng hai ma trận  
    public MaTran Cong(MaTran b)
    {
        if (this.soDong != b.soDong || this.soCot != b.soCot)
        {
            throw new Exception("Hai ma tran phai cung cap.");
        }

        MaTran tong = new MaTran(soDong, soCot);
        for (int i = 0; i < soDong; i++)
        {
            for (int j = 0; j < soCot; j++)
            {
                tong.mang[i, j] = this.mang[i, j] + b.mang[i,