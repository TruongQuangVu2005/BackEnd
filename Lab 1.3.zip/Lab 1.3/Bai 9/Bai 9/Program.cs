﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        QLBienLai qlbl = new QLBienLai();
        qlbl.Run();
    }
}

// Lớp KhachHang  
class KhachHang
{
    public string HoTenChuHo { get; set; }
    public string SoNha { get; set; }
    public string MaSoCongTo { get; set; }

    public void Nhap()
    {
        Console.Write("Nhap ho ten chu ho: ");
        HoTenChuHo = Console.ReadLine();
        Console.Write("Nhap so nha: ");
        SoNha = Console.ReadLine();
        Console.Write("Nhap ma so cong to: ");
        MaSoCongTo = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten chu ho: {HoTenChuHo}, So nha: {SoNha}, Ma so cong to: {MaSoCongTo}");
    }
}

// Lớp BienLai  
class BienLai
{
    public KhachHang HoSuDung { get; set; }
    public int ChiSoCu { get; set; }
    public int ChiSoMoi { get; set; }

    public BienLai()
    {
        HoSuDung = new KhachHang();
    }

    public void Nhap()
    {
        HoSuDung.Nhap();
        Console.Write("Nhap chi so cu: ");
        ChiSoCu = int.Parse(Console.ReadLine());
        Console.Write("Nhap chi so moi: ");
        ChiSoMoi = int.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.WriteLine("=== BIEN LAI THU TIEN DIEN ===");
        HoSuDung.HienThi();
        Console.WriteLine($"Chi so cu: {ChiSoCu}, Chi so moi: {ChiSoMoi}, So tien phai tra: {TinhTienDien()} VND");
    }

    public double TinhTienDien()
    {
        int soDienSuDung = ChiSoMoi - ChiSoCu;
        double soTien = 0;

        if (soDienSuDung <= 50)
        {
            soTien = soDienSuDung * 1250;
        }
        else if (soDienSuDung <= 100)
        {
            soTien = 50 * 1250 + (soDienSuDung - 50) * 1500;
        }
        else
        {
            soTien = 50 * 1250 + 50 * 1500 + (soDienSuDung - 100) * 2000;
        }

        return soTien;
    }
}

// Lớp QLBienLai  
class QLBienLai
{
    private List<BienLai> danhSachBienLai;

    public QLBienLai()
    {
        danhSachBienLai = new List<BienLai>();
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY BIEN LAI THU TIEN DIEN =====");
            Console.WriteLine("1. Nhap danh sach ho su dung dien");
            Console.WriteLine("2. Hien thi thong tin cac bien lai");
            Console.WriteLine("3. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    HienThiDanhSach();
                    break;
                case 3:
                    Console.WriteLine("Thoat khoi chuong trinh