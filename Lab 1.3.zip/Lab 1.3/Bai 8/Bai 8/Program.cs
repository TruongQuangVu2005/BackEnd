﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        QLTheMuon qltm = new QLTheMuon();
        qltm.Run();
    }
}

// Lớp SinhVien  
class SinhVien
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public string Lop { get; set; }
    public string MaSoSinhVien { get; set; }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        NamSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap lop: ");
        Lop = Console.ReadLine();
        Console.Write("Nhap ma so sinh vien: ");
        MaSoSinhVien = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Nam sinh: {NamSinh}, Lop: {Lop}, Ma so sinh vien: {MaSoSinhVien}");
    }
}

// Lớp TheMuon  
class TheMuon
{
    public string SoPhieuMuon { get; set; }
    public DateTime NgayMuon { get; set; }
    public DateTime HanTra { get; set; }
    public string SoHieuSach { get; set; }
    public SinhVien DocGia { get; set; }

    public TheMuon()
    {
        DocGia = new SinhVien();
    }

    public void Nhap()
    {
        Console.Write("Nhap so phieu muon: ");
        SoPhieuMuon = Console.ReadLine();
        Console.Write("Nhap ngay muon (dd/MM/yyyy): ");
        NgayMuon = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
        Console.Write("Nhap han tra (dd/MM/yyyy): ");
        HanTra = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);
        Console.Write("Nhap so hieu sach: ");
        SoHieuSach = Console.ReadLine();
        Console.WriteLine("Nhap thong tin sinh vien:");
        DocGia.Nhap();
    }

    public void HienThi()
    {
        Console.WriteLine($"So phieu muon: {SoPhieuMuon}, Ngay muon: {NgayMuon.ToString("dd/MM/yyyy")}, Han tra: {HanTra.ToString("dd/MM/yyyy")}, So hieu sach: {SoHieuSach}");
        DocGia.HienThi();
    }

    public bool DaDenHan()
    {
        return DateTime.Now > HanTra; // Kiểm tra xem đã đến hạn trả sách chưa  
    }
}

// Lớp QLTheMuon  
class QLTheMuon
{
    private List<TheMuon> danhSachTheMuon;

    public QLTheMuon()
    {
        danhSachTheMuon = new List<TheMuon>();
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY THE MUON =====");
            Console.WriteLine("1. Nhap danh sach sinh vien");
            Console.WriteLine("2. Tim kiem sinh vien theo ma so sinh vien");
            Console.WriteLine("3. Hien thi sinh vien da den han tra sach");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSach();
                    break;
                case 2:
                    TimKiemTheoMaSoSinhVien();
                    break;
                case 3:
                    HienThiDanhsachDenHanTra();
                    break;
                case 