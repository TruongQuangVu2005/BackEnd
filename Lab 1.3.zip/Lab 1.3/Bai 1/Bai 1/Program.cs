﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        QLCB qlcb = new QLCB();
        qlcb.Run();
    }
}

// Lớp CanBo  
class CanBo
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public string GioiTinh { get; set; }
    public string DiaChi { get; set; }

    public virtual void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        NamSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap gioi tinh: ");
        GioiTinh = Console.ReadLine();
        Console.Write("Nhap dia chi: ");
        DiaChi = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Nam sinh: {NamSinh}, Gioi tinh: {GioiTinh}, Dia chi: {DiaChi}");
    }
}

// Lớp CongNhan kế thừa từ CanBo  
class CongNhan : CanBo
{
    public int Bac { get; set; }

    public override void Nhap()
    {
        base.Nhap(); // Gọi phương thức Nhap của lớp cha  
        Console.Write("Nhap bac cong nhan: ");
        Bac = int.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi(); // Gọi phương thức HienThi của lớp cha  
        Console.WriteLine($"Bac cong nhan: {Bac}");
    }
}

// Lớp KySu kế thừa từ CanBo  
class KySu : CanBo
{
    public string NganhDaoTao { get; set; }

    public override void Nhap()
    {
        base.Nhap(); // Gọi phương thức Nhap của lớp cha  
        Console.Write("Nhap nganh dao tao: ");
        NganhDaoTao = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi(); // Gọi phương thức HienThi của lớp cha  
        Console.WriteLine($"Nganh dao tao: {NganhDaoTao}");
    }
}

// Lớp NhanVien kế thừa từ CanBo  
class NhanVien : CanBo
{
    public string CongViec { get; set; }

    public override void Nhap()
    {
        base.Nhap(); // Gọi phương thức Nhap của lớp cha  
        Console.Write("Nhap cong viec: ");
        CongViec = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi(); // Gọi phương thức HienThi của lớp cha  
        Console.WriteLine($"Cong viec: {CongViec}");
    }
}

// Lớp QLCB  
class QLCB
{
    private List<CanBo> danhSachCanBo = new List<CanBo>();

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY CAN BO =====");
            Console.WriteLine("1. Nhap thong tin can bo");
            Console.WriteLine("2. Tim kiem the ho ten");
            Console.WriteLine("3. Hien thi thong tin can bo");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon của bạn: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapThongTin();
                    break;
                case 2:
                    TimKiemTheoHoTen();
                    break;
                case 3:
                    HienThiThongTin();
                    break;
                case 4:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 4);
    }

    private void NhapThongTin()
    {
        Console.WriteLine("Chon loai can bo de nhap thong tin:");
        Console.WriteLine("1. Cong nhan");
        Console.WriteLine("2. Ky su");
        Console.WriteLine("3. Nhan vien phuc vu");
        Console.Write("Nhap lua chon: ");
       