﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        QLCBGV qlcbgv = new QLCBGV();
        qlcbgv.Run();
    }
}

// Lớp Nguoi  
class Nguoi
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public string QueQuan { get; set; }
    public string SoCMND { get; set; }

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap nam sinh: ");
        NamSinh = int.Parse(Console.ReadLine());
        Console.Write("Nhap que quan: ");
        QueQuan = Console.ReadLine();
        Console.Write("Nhap so CMND: ");
        SoCMND = Console.ReadLine();
    }

    public void HienThi()
    {
        Console.WriteLine($"Ho ten: {HoTen}, Nam sinh: {NamSinh}, Que quan: {QueQuan}, So CMND: {SoCMND}");
    }
}

// Lớp CBGV  
class CBGV
{
    public Nguoi ThongTinCaNhan { get; set; }
    public double LuongCung { get; set; }
    public double Thuong { get; set; }
    public double Phat { get; set; }

    public CBGV()
    {
        ThongTinCaNhan = new Nguoi();
    }

    public void Nhap()
    {
        Console.WriteLine("Nhap thong tin ca nhan:");
        ThongTinCaNhan.Nhap();
        Console.Write("Nhap luong cứng: ");
        LuongCung = double.Parse(Console.ReadLine());
        Console.Write("Nhap thuong: ");
        Thuong = double.Parse(Console.ReadLine());
        Console.Write("Nhap phat: ");
        Phat = double.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.WriteLine($"Luong thuc linh: {TinhLuongThucLinh()}, ");
        ThongTinCaNhan.HienThi();
    }

    public double TinhLuongThucLinh()
    {
        return LuongCung + Thuong - Phat;
    }
}

// Lớp QLCBGV  
class QLCBGV
{
    private List<CBGV> danhSachCBGV;

    public QLCBGV()
    {
        danhSachCBGV = new List<CBGV>();
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("===== QUAN LY CAN BO GIAO VIEN =====");
            Console.WriteLine("1. Nhap danh sach can bo giao vien");
            Console.WriteLine("2. Tim kiem theo que quan");
            Console.WriteLine("3. Hien thi cac can bo co luong thuc linh tren 5 trieu");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapDanhSachCBGV();
                    break;
                case 2:
                    TimKiemTheoQueQuan();
                    break;
                case 3:
                    HienThiCBGVCoLuongTren5Trieu();
                    break;
                case 4:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 