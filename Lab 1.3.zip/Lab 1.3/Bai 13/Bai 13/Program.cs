﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        QLPTGT qlptgt = new QLPTGT();
        qlptgt.Run();
    }
}

// Lớp PTGT  
class PTGT
{
    public string HangSanXuat { get; set; }
    public int NamSanXuat { get; set; }
    public double GiaBan { get; set; }
    public string Mau { get; set; }

    public virtual void Nhap()
    {
        Console.Write("Nhap hang san xuat: ");
        HangSanXuat = Console.ReadLine();
        Console.Write("Nhap nam san xuat: ");
        NamSanXuat = int.Parse(Console.ReadLine());
        Console.Write("Nhap gia ban: ");
        GiaBan = double.Parse(Console.ReadLine());
        Console.Write("Nhap mau: ");
        Mau = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Hang san xuat: {HangSanXuat}, Nam san xuat: {NamSanXuat}, Gia ban: {GiaBan:F2} VND, Mau: {Mau}");
    }
}

// Lớp OTo  
class OTo : PTGT
{
    public int SoCho { get; set; }
    public string KieuDongCo { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap so cho ngoi: ");
        SoCho = int.Parse(Console.ReadLine());
        Console.Write("Nhap kieu dong co: ");
        KieuDongCo = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"So cho ngoi: {SoCho}, Kieu dong co: {KieuDongCo}");
    }
}

// Lớp XeMay  
class XeMay : PTGT
{
    public double CongSuat { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap cong suat: ");
        CongSuat = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Cong suat: {CongSuat} HP");
    }
}

// Lớp XeTai  
class XeTai : PTGT
{
    public double TrongTai { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap trong tai: ");
        TrongTai = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Trong tai: {TrongTai} kg");
    }
}

// Lớp QLPTGT  
class QLPTGT
{
    private List<PTGT> danhSachPTGT;

    public QLPTGT()
    {
        danhSachPTGT = new List<PTGT>();
    }

    public void Run()
    {
        int luaChon;
        do
        {
            Console.WriteLine("\n===== QUAN LY PHUONG TIEN GIAO THONG =====");
            Console.WriteLine("1. Nhap dang ky phuong tien");
            Console.WriteLine("2. Tim phuong tien theo mau hoac theo nam san xuat");
            Console.WriteLine("3. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    NhapPhuongTien();
                    break;

                case 2:
                    TimPhuongTien();
                    break;

                case 3:
                    Console.WriteLine("Ket thuc chuong trinh.");
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 3);
    }

    private void NhapPhuongTien()
    {
        Console.WriteLine("Chon loai phuong tien:");
        Console.WriteLine("1. O to");
        Console.WriteLine("2. Xe may");
        Console.WriteLine("3. Xe tai");
        Console.Write("Nhap lua chon: ");
       