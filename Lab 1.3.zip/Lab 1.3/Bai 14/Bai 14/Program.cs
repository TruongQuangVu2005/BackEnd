﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Nhap phan so A:");
        PhanSo A = new PhanSo();
        A.Nhap();

        Console.WriteLine("Nhap phan so B:");
        PhanSo B = new PhanSo();
        B.Nhap();

        while (true)
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Cong hai phan so");
            Console.WriteLine("2. Tru hai phan so");
            Console.WriteLine("3. Chia hai phan so");
            Console.WriteLine("4. Thoat");
            Console.Write("Nhap lua chon: ");
            int luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    PhanSo tong = A.Cong(B);
                    Console.WriteLine($"Tong: {tong}");
                    break;
                case 2:
                    PhanSo hieu = A.Tru(B);
                    Console.WriteLine($"Hieu: {hieu}");
                    break;
                case 3:
                    PhanSo thuong = A.Chia(B);
                    Console.WriteLine($"Thuong: {thuong}");
                    break;
                case 4:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    return;
                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        }
    }
}

// Lớp PhanSo  
class PhanSo
{
    private int tuSo; // Tử số  
    private int mauSo; // Mẫu số  

    // Hàm tạo mặc định  
    public PhanSo()
    {
        tuSo = 0;
        mauSo = 1; // Mẫu số mặc định là 1  
    }

    // Hàm tạo với tử và mẫu  
    public PhanSo(int tu, int mau)
    {
        if (mau == 0)
        {
            throw new ArgumentException("Mau so phai khac 0.");
        }
        tuSo = tu;
        mauSo = mau;
        RutGon();
    }

    // Phương thức nhập phân số  
    public void Nhap()
    {
        Console.Write("Nhap tu so: ");
        tuSo = int.Parse(Console.ReadLine());
        Console.Write("Nhap mau so: ");
        mauSo = int.Parse(Console.ReadLine());
        if (mauSo == 0)
        {
            throw new ArgumentException("Mau so phai khac 0.");
        }
        RutGon();
    }

    // Phương thức hiển thị phân số  
    public override string ToString()
    {
        return $"{tuSo}/{mauSo}";
    }

    // Phương thức rút gọn phân số  
    private void RutGon()
    {
        int gcd = Gcd(tuSo, mauSo);
        tuSo /= gcd;
        mauSo /= gcd;

        // Đảm bảo mauSo luôn dương  
        if (mauSo < 0)
        {
            tuSo = -tuSo;
            mauSo = -mauSo;
        }
    }

    // Phương thức tìm ucln  
    private int Gcd(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return Math.Abs(a); // Trả về giá trị tuyệt đối  
    }

    // Phương thức cộng hai phân số  
    public PhanSo Cong(PhanSo b)
    {
        int tu = this.tuSo * b.mauSo + b.tuSo * this.mauSo;
        int mau = this.mauSo * b.mauSo;
        return new PhanSo(tu, mau);
    }

    // Phương thức trừ hai phân số  
    public PhanSo Tru(PhanSo b)
    {
        int tu = this.tuSo * b.mauSo - b.tuSo * this.mauSo;
        int mau = this.mauSo * b.mauSo;
        return new PhanSo(tu, mau);
    }

    // Phương thức chia hai phân