﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        TuyenSinh tuyenSinh = new TuyenSinh();
        tuyenSinh.Run();
    }
}

// Lớp ThiSinh  
class ThiSinh
{
    public string SoBaoDanh { get; set; }
    public string HoTen { get; set; }
    public string DiaChi { get; set; }
    public float UuTien { get; set; }
    public virtual void Nhap()
    {
        Console.Write("Nhap so bao danh: ");
        SoBaoDanh = Console.ReadLine();
        Console.Write("Nhap ho ten: ");
        HoTen = Console.ReadLine();
        Console.Write("Nhap dia chi: ");
        DiaChi = Console.ReadLine();
        Console.Write("Nhap uu tien: ");
        UuTien = float.Parse(Console.ReadLine());
    }

    public virtual float TinhDiem()
    {
        return UuTien;
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"So bao danh: {SoBaoDanh}, Ho ten: {HoTen}, Dia chi: {DiaChi}, Uu tien: {UuTien}");
    }
}

// Lớp ThiSinhKhoiA kế thừa từ ThiSinh  
class ThiSinhKhoiA : ThiSinh
{
    public float DiemToan { get; set; }
    public float DiemLy { get; set; }
    public float DiemHoa { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap diem Toan: ");
        DiemToan = float.Parse(Console.ReadLine());
        Console.Write("Nhap diem Ly: ");
        DiemLy = float.Parse(Console.ReadLine());
        Console.Write("Nhap diem Hoa: ");
        DiemHoa = float.Parse(Console.ReadLine());
    }

    public override float TinhDiem()
    {
        return DiemToan + DiemLy + DiemHoa + UuTien;
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Diem Toan: {DiemToan}, Diem Ly: {DiemLy}, Diem Hoa: {DiemHoa}, Tong diem: {TinhDiem()}");
    }
}

// Lớp ThiSinhKhoiB kế thừa từ ThiSinh  
class ThiSinhKhoiB : ThiSinh
{
    public float DiemToan { get; set; }
    public float DiemHoa { get; set; }
    public float DiemSinh { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhap diem Toan: ");
        DiemToan = float.Parse(Console.ReadLine());
        Console.Write("Nhap diem Hoa: ");
        DiemHoa = float.Parse(Console.ReadLine());
        Console.Write("Nhap diem Sinh: ");
        DiemSinh = float.Parse(Console.ReadLine());
    }

    public override float TinhDiem()
    {
        return DiemToan + DiemHoa + DiemSinh + UuTien;
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Diem Toan: {DiemToan}, Diem Hoa: {D