﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        List<HocSinh> danhSachHocSinh = new List<HocSinh>();

        Console.Write("Nhap so luong hoc sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhap thong tin hoc sinh {i + 1}:");
            HocSinh hocSinh = NhapHocSinh();
            danhSachHocSinh.Add(hocSinh);
        }

        // Sắp xếp theo tổng điểm giảm dần, năm sinh nhỏ hơn đứng trước  
        danhSachHocSinh = danhSachHocSinh
            .OrderByDescending(hs => hs.TongDiem)
            .ThenBy(hs => hs.NamSinh)
            .ToList();

        // In ra danh sách đã sắp xếp  
        Console.WriteLine("\nDanh sach hoc sinh sau khi sap xep:");
        foreach (var hs in danhSachHocSinh)
        {
            hs.InThongTin();
        }
    }

    static HocSinh NhapHocSinh()
    {
        Console.Write("Nhap ho ten: ");
        string hoTen = Console.ReadLine();

        Console.Write("Nhap nam sinh: ");
        int namSinh = int.Parse(Console.ReadLine());

        Console.Write("Nhap tong diem: ");
        double tongDiem = double.Parse(Console.ReadLine());

        return new HocSinh(hoTen, namSinh, tongDiem);
    }
}

// Lớp HocSinh  
class HocSinh
{
    public string HoTen { get; set; }
    public int NamSinh { get; set; }
    public double TongDiem { get; set; }

    public HocSinh(string hoTen, int namSinh, double tongDiem)
    {
        HoTen = hoTen;
        NamSinh = namSinh;
        TongDiem = tongDiem;
    }

    public void InThongTin()
    {
        // Chuyển đổi họ tên sao cho ký tự đầu tiên của mỗi phần tên được viết hoa  
        string hoTenHoa = System.Threading.Thread.CurrentThread.CurrentCulture.TextInfo.ToTitleCase(HoTen.ToLower());

        Console.WriteLine($"Ho ten: {hoTenHoa}, Nam sinh: {NamSinh}, Tong diem: {TongDiem}");
    }
}