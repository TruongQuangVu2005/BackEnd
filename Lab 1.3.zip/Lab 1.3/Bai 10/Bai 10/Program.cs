﻿using System;

class Program
{
    static void Main(string[] args)
    {
        VanBan vanBan = null;
        int luaChon;

        do
        {
            Console.WriteLine("===== MENU =====");
            Console.WriteLine("1. Nhap xau van ban");
            Console.WriteLine("2. Dem so tu trong van ban");
            Console.WriteLine("3. Dem so ky tu 'H' trong van ban");
            Console.WriteLine("4. Chuan hoa xau van ban");
            Console.WriteLine("5. Thoat");
            Console.Write("Nhap lua chon: ");
            luaChon = int.Parse(Console.ReadLine());

            switch (luaChon)
            {
                case 1:
                    Console.Write("Nhap xau van ban: ");
                    string input = Console.ReadLine();
                    vanBan = new VanBan(input);
                    break;

                case 2:
                    if (vanBan != null)
                    {
                        Console.WriteLine($"So tu trong van ban: {vanBan.DemTu()}");
                    }
                    else
                    {
                        Console.WriteLine("Ban chua nhap xau van ban.");
                    }
                    break;

                case 3:
                    if (vanBan != null)
                    {
                        Console.WriteLine($"So ky tu 'H' trong van ban: {vanBan.DemKyTuH()}");
                    }
                    else
                    {
                        Console.WriteLine("Ban chua nhap xau van ban.");
                    }
                    break;

                case 4:
                    if (vanBan != null)
                    {
                        string chuanHoa = vanBan.ChuanHoa();
                        Console.WriteLine($"Xau van ban sau khi chuan hoa: '{chuanHoa}'");
                    }
                    else
                    {
                        Console.WriteLine("Ban chua nhap xau van ban.");
                    }
                    break;

                case 5:
                    Console.WriteLine("Thoat khoi chuong trinh.");
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le. Vui long chon lai.");
                    break;
            }
        } while (luaChon != 5);
    }
}

// Lớp VanBan  
class VanBan
{
    private string st;

    // Hàm tạo không có đối số  
    public VanBan()
    {
        st = string.Empty;
    }

    // Hàm tạo với xâu đầu vào  
    public VanBan(string st)
    {
        this.st = st;
    }

    // Phương thức đếm số từ  
    public int DemTu()
    {
        if (string.IsNullOrWhiteSpace(st))
            return 0;

        // Tách xâu theo khoảng trắng và đếm số từ  
        string[] tu = st.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        return tu.Length;
    }

    // Phương thức đếm số ký tự 'H'  
    public int DemKyTuH()
    {
        int count = 0;

        foreach (char c in st)
        {
            if (char.ToUpper(c) == 'H')
            {
                count++;
            }
        }
        return count;
    }

    // Phương thức chuẩn hoá xâu  
    public string ChuanHoa()
    {
        if (string.IsNullOrWhiteSpace(st))
            return string.Empty;

        // Cắt và chuẩn hoá khoảng trắng  
        string[] parts = st.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        return string.Join(" ", parts);
    }
}