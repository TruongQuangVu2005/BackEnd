﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Nhap so luong tam giac: ");
        int n = int.Parse(Console.ReadLine());

        TamGiac[] tamGiacArray = new TamGiac[n];

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap tam giac thu {i + 1}:");
            tamGiacArray[i] = new TamGiac();
            tamGiacArray[i].Nhap();
        }

        Console.WriteLine("\nCac tam giac thoa man dinh ly Pytago:");
        foreach (var tamGiac in tamGiacArray)
        {
            if (tamGiac.KiemTraPytago())
            {
                Console.WriteLine($"Tam giac: {tamGiac}");
            }
        }
    }
}

// Lớp DaGiac  
class DaGiac
{
    protected int soCanh;  // Số cạnh  
    protected int[] kichThuocCacCanh; // Mảng chứa kích thước các cạnh  

    public DaGiac(int soCanh)
    {
        this.soCanh = soCanh;
        kichThuocCacCanh = new int[soCanh];
    }

    public virtual void Nhap()
    {
        for (int i = 0; i < soCanh; i++)
        {
            Console.Write($"Nhap kich thuoc canh {i + 1}: ");
            kichThuocCacCanh[i] = int.Parse(Console.ReadLine());
        }
    }

    public virtual int TinhChuVi()
    {
        int chuVi = 0;
        foreach (var canh in kichThuocCacCanh)
        {
            chuVi += canh;
        }
        return chuVi;
    }

    public void InCacCanh()
    {
        Console.Write("Cac canh: ");
        foreach (var canh in kichThuocCacCanh)
        {
            Console.Write(canh + " ");
        }
        Console.WriteLine();
    }

    public override string ToString()
    {
        return string.Join(", ", kichThuocCacCanh);
    }
}

// Lớp TamGiac  
class TamGiac : DaGiac
{
    public TamGiac() : base(3) // Khởi tạo với số cạnh là 3  
    {
    }

    public override void Nhap()
    {
        base.Nhap();
    }

    public override int TinhChuVi()
    {
        return base.TinhChuVi(); // Gọi phương thức tính chu vi của da giác  
    }

    public double TinhDienTich()
    {
        double p = TinhChuVi() / 2.0;
        double dientich = Math.Sqrt(p * (p - kichThuocCacCanh[0]) * (p - kichThuocCacCanh[1]) * (p - kichThuocCacCanh[2]));
        return dientich;
    }

    // Phương thức kiểm tra tam giác thỏa mãn định lý Pytago  
    public bool KiemTraPytago()
    {
        Array.Sort(kichThuocCacCanh); // Sắp xếp các cạnh  
        return (kichThuocCacCanh[0] * kichThuocCacCanh[0] + kichThuocCacCanh[1] * kichThuocCacCanh[1]) == (kichThuocCacCanh[2] * kichThuocCacCanh[2]);
    }
}